<?php
//$hostname="localhost";
//$database="simplepo_20200414";
//$username="simplepo_root";
//$password="123Simple456$";

$hostname="localhost";
$database="simplepos";
$username="root";
$password="";

?>