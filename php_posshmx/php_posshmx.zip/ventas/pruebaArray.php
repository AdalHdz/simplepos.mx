<?php
    $ventas=array("RANCHERITOS","MANTECADAS");
    
    for($i=0; $i<sizeof($ventas); ++$i){
        echo $ventas[$i];
    }
?>