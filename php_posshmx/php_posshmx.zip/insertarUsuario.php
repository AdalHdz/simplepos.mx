<?php
require("conexion.php");

if(isset ($_POST['nombre']) && isset ($_POST['user']) && isset ($_POST['pwd']) && isset ($_POST['correo'])){
    $unombre=$_POST['nombre'];
    $uuser=$_POST['user'];
    $upwd=$_POST['pwd'];
    $ucorreo=$_POST['correo'];

    $conexion=mysqli_connect($hostname,$username,$password,$database);
    
    $query = "SELECT mail FROM tb_usuario WHERE mail='$ucorreo' AND idStatusUsuario = '1'";

        $resultado = mysqli_query($conexion, $query) or die (mysqli_error());

        if(mysqli_fetch_array($resultado)){
            $data{'mensaje'} = "ESTE CORREO YA HA SIDO USADO";
            $data{'continua'} = "0";
            echo json_encode($data);
        }else{
            $consulta="INSERT INTO tb_usuario(nombre, nombreUsuario, pass, mail, idStatusUsuario) VALUES ('$unombre','$uuser','$upwd','$ucorreo','1')";
            $result = mysqli_query($conexion, $consulta) or die (mysqli_error());
            if($result){
                $data{'mensaje'} = "USUARIO CREADO";
                $data{'continua'} = "1";
                echo json_encode ($data);
            }else{
                $data{'mensaje'} = "ERROR";
                $data{'continua'} = "0";
                echo json_encode ($data);
            }         
        }
}else{
    $data{'mensaje'} = "NO HAY DATOS";
    $data{'continua'} = "0"; 
    echo json_encode ($data);
}

mysqli_close($conexion);

?>
